package com.example.WeatherApp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
